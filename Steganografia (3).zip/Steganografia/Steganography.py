from PIL import Image
import numpy as np
import scipy.misc
import random

# make red flower
def makered():
    i = Image.open('flower.jpg')
    dim = np.zeros((i.size[1], i.size[0]), 'int8')
    
    img_zero = Image.fromarray(dim, 'L')
    img = Image.merge('RGB', (i, img_zero, img_zero)) # in this variant will be easy to encode
    img.save('redflower.bmp') # (!) important to use bmp; jpg does some image conversion while saving
    # other options to save are, e.g.:      scipy.misc.toimage(numpytable, cmin=0, cmax=255).save(stringfilename) 
    
makered()

def decode(image):
    irgb = Image.open(image)
    ired = Image.open('redflower.bmp')
    iblue = np.subtract(irgb, ired)     # leave only values outside of red layer

    decrypted = ''

    for value in iblue[iblue > 0]:

        decrypted += chr(value)
    
    print(decrypted)


def encode(image, message):
    i = Image.open(image)
    width = i.size[0]
    height = i.size[1]


    randomized_spots = random.sample(range(width * height), len(message))     # randomly choose indices where the message is going to be encoded
    blue_pixels = np.zeros(width * height,'int8')
    green_pixels = np.zeros(width * height,'int8')


    for j in range(len(blue_pixels)):           # mark chosen indices in the blue layer
        if j in randomized_spots:
            blue_pixels[j] = 1


    blue_pixels = blue_pixels.reshape(height, width)
    green_pixels = green_pixels.reshape(height, width)


    index = 0                                            # place characters from the message in the chosen places
    for row in range(height):
        for column in range(width):
            if (blue_pixels[row, column] == 1):
                 blue_pixels[row, column] = ord(message[index])
                 index += 1


    blue_img = Image.fromarray(blue_pixels, "L")         # merge red layer of original image with blue layer containing hidden message
    green_img = Image.fromarray(green_pixels, "L")

    img = Image.merge('RGB', (i, green_img, blue_img)) 
    img.save('encrypted.bmp')

    

decode('crypto.bmp')

encode('flower.jpg', 'There is no secret message')

decode('encrypted.bmp')
