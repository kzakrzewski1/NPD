import json
import pytest
import requests
import nbp_change
from pytest import MonkeyPatch 
from nbp_change import calc_statistics, get_courses


def mock_get_courses(d1,d2):
    with open('data_CHF.json', 'r') as f:
        data = json.load(f)
    return [x["mid"] for x in data["rates"]], data["currency"]

def test_calc_statistics(monkeypatch):
    monkeypatch.setattr(nbp_change, 'get_courses', mock_get_courses)
    assert calc_statistics(['USD'],15)['USD']['course'] == 4.7472
    assert calc_statistics(['USD'],15)['USD']['change'] == 0.9929926579789571
    assert calc_statistics(['USD'],15)['USD']['full_name'] == 'frank szwajcarski'


