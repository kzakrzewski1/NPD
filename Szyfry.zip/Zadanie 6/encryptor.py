import argparse
from ceasar import encrypt, decrypt


parser = argparse. ArgumentParser()
parser.add_argument("-d", dest = "decrypt", action = "store_true", help = "decrypt file")
parser.add_argument("-e", dest = "encrypt", action = "store_true", help = "encrypt file")
parser.add_argument("-c", dest = "ceasar", action = "store_true", help = "use ceasar cipher")
parser.add_argument("n", type = int, default=0, nargs="?", help = "shift to be used in ceasar cipher")
parser.add_argument("input_file", help = "file to be read")
parser.add_argument("output_file", help = "file to save result")

args = parser.parse_args()

if args.encrypt and args.decrypt:
    parser.error("choose either -e or -d")
else: 
    if args.encrypt:
        if args.ceasar:
            encrypt(args.input_file, args.output_file, args.n)

    if args.decrypt:
        if args.ceasar:
            decrypt(args.input_file, args.output_file, args.n)

