

def encrypt(file_name, out_name, shift):
    g = open(file_name, 'r', encoding='utf-8')
    text = g.read()
    g.close()
    result = ""
    for i in range(len(text)):
        char = text[i]

        if char == " ":
            result += " "
            continue

        # print(text)
        if (char.isupper()):
            result += chr((ord(char) + shift-65) % 26 + 65)
        else:
            result += chr((ord(char) + shift - 97) % 26 + 97)
            
    g = open(out_name, 'w', encoding='utf-8')
    g.write(f'{result}')
    g.close()


def decrypt(file_name, out_name, shift):
    g = open(file_name, 'r', encoding='utf-8')
    text = g.read()
    result = ""
    for i in range(len(text)):
        char = text[i]

        if char == " ":
            result += " "
            continue

        if (char.isupper()):
            result += chr((ord(char) - shift-65) % 26 + 65)
        else:
            result += chr((ord(char) - shift - 97) % 26 + 97)

    g = open(out_name, 'w', encoding='utf-8')
    g.write(f'{result}')
    g.close()
