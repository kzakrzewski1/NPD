echo Liczba sekwencji w pliku 1:
grep -o ">" b1.txt | wc -l
echo Liczba sekwencji w pliku 2:
grep -o ">" b2.txt | wc -l

echo Spike protein 1:
sed -n "/spike/,/>/{//!p}" b1.txt
sed -n '/spike/,/>/{//!p}' b1.txt > out1.txt

echo Spike protein 2:
sed -n '/spike/,/>/{//!p}' b2.txt
sed -n '/spike/,/>/{//!p}' b2.txt > out2.txt


diff out1.txt out2.txt

